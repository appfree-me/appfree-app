<?php
declare(strict_types=1);
namespace PhpAri3\interfaces\old;

use Exception;
use GuzzleHttp\Exception\GuzzleException;
use PhpAri3\PhpAri;

/**
 * PhpAri - A PHP Class Library for interfacing with Asterisk(R) ARI
 * Copyright (C) 2014  Nir Simionovich
 */
class Asterisk
{

	private PhpAri $phpAriObject;

	function __construct(PhpAri $PhpAriObject)
	{
            $this->phpAriObject = $PhpAriObject;
	}

	/**
	 * This function is an alias to 'info' - will be deprecated in PhpAri 2.0
	 *
	 * @param null $filter
	 *
	 * @return mixed
	 */
	public function get_asterisk_info($filter = NULL): mixed
    {
		return $this->info($filter);
	}

	public function info($filter = NULL): mixed
    {

		try {

			$result = FALSE;

			switch ($filter) {
				case "build":
				case "system":
				case "config":
				case "status":
					break;
				default:
					$filter = NULL;
					break;
			}

			$uri = "/asterisk/info";
			$uri .= (!is_null($filter)) ? '?only=' . $filter : '';
//fixme wird nicht funzelnieren
			$result = json_decode($this->phpAriObject->ariEndpoint->get($this->phpAriObject->baseUri . $uri, $this->phpAriObject->ariEndpointOptions)->getBody()->getContents());

			return $result;

		} catch (\GuzzleHttp\Exception\RequestException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ClientException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ServerException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (Exception $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();

			return FALSE;
		}

	}

	/**
	 * @param null $variable
	 *
	 * @return bool
	 */
	public function getGlobalVariable($variable = NULL)
	{
		try {

			$result = FALSE;

			if (is_null($variable))
				throw new Exception("Global variable name not provided or is null", 503);

			$uri = "/asterisk/variable?variable=" . $variable;
			$jsonResult = $this->pestObject->get($uri);

            return json_decode($this->phpAriObject->ariEndpoint->get($this->phpAriObject->baseUri . $uri, $this->phpAriObject->ariEndpointOptions)->getBody()->getContents());

		} catch (\GuzzleHttp\Exception\RequestException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ClientException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ServerException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (Exception $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();

			return FALSE;
		}
	}

    // fixme this probably doesnt work
	public function get_global_variable(array|string $variable): mixed
	{
		return $this->setGlobalVariable($variable, null);
	}


	public function setGlobalVariable(array|string $variable, array|string|null $value): mixed
	{
		try {


			$uri = "/asterisk/variable";
			$postData = array("variable" => $variable, "value" => $value);

			$this->phpAriObject->ariEndpointOptions['json'] = $postData;
            return json_decode($this->phpAriObject->ariEndpoint->post($this->phpAriObject->baseUri . $uri, $this->phpAriObject->ariEndpointOptions)->getBody()->getContents());

		} catch (\GuzzleHttp\Exception\RequestException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ClientException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ServerException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (Exception $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();

			return FALSE;
		}
	}

	/*
	 * This is an alias to setGlobalVariable
	 */
	public function set_global_variable($variable, $value): mixed
	{
		return $this->setGlobalVariable($variable, $value);
	}

    /**
     * @throws GuzzleException
     */
	public function getDynamicConfigurationObject($configClass = NULL, $objectType = NULL, $id = NULL): mixed
	{
		try {


			if (is_null($configClass))
				throw new Exception("configClass variable name not provided or is null", 503);

			if (is_null($objectType))
				throw new Exception("objectType variable value not provided or is null", 503);

			if (is_null($id))
				throw new Exception("id variable value not provided or is null", 503);

			$uri = "/asterisk/config/dynamic/" . $configClass . "/" . $objectType . "/" . $id;
            return json_decode($this->phpAriObject->ariEndpoint->get($this->phpAriObject->baseUri . $uri, $this->phpAriObject->ariEndpointOptions)->getBody()->getContents());

		} catch (\GuzzleHttp\Exception\RequestException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ClientException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ServerException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (Exception $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();

			return FALSE;
		}
	}

	public function get_dynamic_configuration_object($configClass = NULL, $objectType = NULL, $id = NULL): mixed
	{
		return $this->getDynamicConfigurationObject($configClass, $objectType, $id);
	}

	public function putDynamicConfigurationObject(string $configClass , string $objectType , string $id , array $fields ): mixed
	{
		try {


			$uri = "/asterisk/config/dynamic/" . $configClass . "/" . $objectType . "/" . $id;

			$this->phpAriObject->ariEndpointOptions['json'] = $fields;
            return json_decode($this->phpAriObject->ariEndpoint->put($this->phpAriObject->baseUri . $uri, $this->phpAriObject->ariEndpointOptions)->getBody()->getContents());

		} catch (\GuzzleHttp\Exception\RequestException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ClientException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ServerException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (Exception $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();

			return FALSE;
		}
	}

	public function put_dynamic_configuration_object($configClass, $objectType , $id , $fields )
	{
		return $this->putDynamicConfigurationObject($configClass, $objectType, $id, $fields);
	}

	public function deleteDynamicConfigurationObject($configClass, $objectType , $id )
	{
		try {


			$uri = "/asterisk/config/dynamic/" . $configClass . "/" . $objectType . "/" . $id;

            return json_decode($this->phpAriObject->ariEndpoint->delete($this->phpAriObject->baseUri . $uri, $this->phpAriObject->ariEndpointOptions)->getBody()->getContents());

		} catch (\GuzzleHttp\Exception\RequestException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ClientException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ServerException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (Exception $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();

			return FALSE;
		}
	}

	/**
	 * @param null $configClass
	 * @param null $objectType
	 * @param null $id
	 * @return bool
	 */
	public function delete_dynamic_configuration_object($configClass = NULL, $objectType = NULL, $id = NULL)
	{
		return $this->deleteDynamicConfigurationObject($configClass, $objectType, $id);
	}


	private function ari_module_handler(string $action = "get", string $module_name): bool|int
    {
		try {

			$result = FALSE;

			$uri = "/asterisk/modules" . $module_name;

			switch ($action) {
				case "get":
					$result = json_decode($this->phpAriObject->ariEndpoint->get($this->phpAriObject->baseUri . $uri, $this->phpAriObject->ariEndpointOptions)->getBody()->getContents());
					break;
				case "load":


					$result = json_decode($this->phpAriObject->ariEndpoint->post($this->phpAriObject->baseUri . $uri, $this->phpAriObject->ariEndpointOptions)->getBody()->getContents());
					break;
				case "unload":


					$result = json_decode($this->phpAriObject->ariEndpoint->delete($this->phpAriObject->baseUri . $uri, $this->phpAriObject->ariEndpointOptions)->getBody()->getContents());
					break;
				case "reload":


					$result = json_decode($this->phpAriObject->ariEndpoint->put($this->phpAriObject->baseUri . $uri, $this->phpAriObject->ariEndpointOptions)->getBody()->getContents());
					break;
			}

			return $result;

		} catch (\GuzzleHttp\Exception\RequestException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ClientException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ServerException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (Exception $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();

			return FALSE;
		}
	}


	public function getModule($module_name)
	{
		return $this->ari_module_handler("get", $module_name);
	}


	public function get_module($module_name)
	{
		return $this->getModule($module_name);
	}

	public function loadModule($module_name)
	{
		return $this->ari_module_handler("load", $module_name);
	}

	public function load_module($module_name)
	{
		return $this->loadModule($module_name);
	}

	public function unloadModule($module_name)
	{
		return $this->ari_module_handler("unload", $module_name);
	}


	public function unload_module($module_name)
	{
		return $this->unloadModule($module_name);
	}


	public function reloadModule($module_name)
	{
		return $this->ari_module_handler("reload", $module_name);
	}


	public function reload_module($module_name)
	{
		return $this->reloadModule($module_name);
	}

	public function getLogChannels()
	{
		try {

			$uri = "/asterisk/logging";

            return json_decode($this->phpAriObject->ariEndpoint->get($this->phpAriObject->baseUri . $uri, $this->phpAriObject->ariEndpointOptions)->getBody()->getContents());

		} catch (\GuzzleHttp\Exception\RequestException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ClientException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ServerException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (Exception $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();

			return FALSE;
		}
	}

	public function get_log_channels()
	{
		return $this->getLogChannels();
	}


	public function addLogChannel(string $log_channel_name, array $configuration): mixed
	{
		try {

			$uri = "/asterisk/logging/" . $log_channel_name;

			$this->phpAriObject->ariEndpointOptions['json'] = $configuration;
            return json_decode($this->phpAriObject->ariEndpoint->post($this->phpAriObject->baseUri . $uri, $this->phpAriObject->ariEndpointOptions)->getBody()->getContents());

		} catch (\GuzzleHttp\Exception\RequestException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ClientException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ServerException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (Exception $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();

			return null;
		}
	}

	public function add_log_channel($log_channel_name, $configuration )
	{
		return $this->addLogChannel($log_channel_name, $configuration);
	}

	public function rotateLogChannel(string $log_channel_name): mixed
	{
		try {

			$uri = "/asterisk/logging/" . $log_channel_name . "/rotate";

            return json_decode($this->phpAriObject->ariEndpoint->put($this->phpAriObject->baseUri . $uri, $this->phpAriObject->ariEndpointOptions)->getBody()->getContents());

		} catch (\GuzzleHttp\Exception\RequestException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ClientException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ServerException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (Exception $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();

			return null;
		}
	}

	public function rotate_log_channel($log_channel_name)
	{
		return $this->rotateLogChannel($log_channel_name);

	}

	public function deleteLogChannel(string $log_channel_name)
	{
		try {

			$uri = "/asterisk/logging/" . $log_channel_name;

            return json_decode($this->phpAriObject->ariEndpoint->delete($this->phpAriObject->baseUri . $uri, $this->phpAriObject->ariEndpointOptions)->getBody()->getContents());

		} catch (\GuzzleHttp\Exception\RequestException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ClientException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (\GuzzleHttp\Exception\ServerException $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();
			return (int)$e->getCode();
		} catch (Exception $e) {
			$this->phpAriObject->lasterror = $e->getMessage();
			$this->phpAriObject->lasttrace = $e->getTraceAsString();

			return FALSE;
		}
	}

	public function delete_log_channel($log_channel_name)
	{
		return $this->deleteLogChannel($log_channel_name);
	}

}