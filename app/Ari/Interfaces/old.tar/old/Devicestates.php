<?php
declare(strict_types=1);
namespace PhpAri3\interfaces\old;

use PhpAri3\interfaces\Exception;

/**
 * phpari - A PHP Class Library for interfacing with Asterisk(R) ARI
 * Copyright (C) 2014  Nir Simionovich
 *

 **/
class Devicestates
{
    private $phpariObject;

    function __construct($connObject = NULL)
    {
        try {

            if (is_null($connObject) || is_null($connObject->ariEndpoint))
                throw new Exception("Missing PestObject or empty string", 503);

            $this->phpariObject = $connObject;
            $this->pestObject = $connObject->ariEndpoint;

        } catch (Exception $e) {
            die("Exception raised: " . $e->getMessage() . "\nFile: " . $e->getFile() . "\nLine: " . $e->getLine());
        }
    }


    /**
     * GET /deviceStates
     * Get a list of current device states, or the device state for a specific device name
     *
     * @return bool
     */
    public function show($deviceName = NULL)
    {
        try {

            if (is_null($this->pestObject))
                throw new Exception("PEST Object not provided or is null", 503);

            $uri = (is_null($deviceName))?"/deviceStates":"/deviceStates/" . $deviceName;
            $result = $this->pestObject->get($uri);
            return $result;

        } catch (Exception $e) {
            $this->phpariObject->lasterror = $e->getMessage();
            $this->phpariObject->lasttrace = $e->getTraceAsString();
            return false;
        }
    }

    /**
     * This function is an alias to 'show' - will be deprecated in phpari 2.0
     *
     * @return mixed
     */
    public function devicestates_list()
    {
        return $this->show();
    }

    /**
     * This function is an alias to 'show' - will be deprecated in phpari 2.0
     *
     * @return mixed
     */
    public function devicestate_currentstate($deviceName = NULL)
    {
        return $this->show($deviceName);
    }

    /**
     *
     *  PUT /deviceStates/{deviceName}
     *  Change the state of a device controlled by ARI.
     *  (Note - implicitly creates the device state).
     *
     *
     * @param null $deviceName
     * @param null $deviceState
     * @return bool
     */
    public function set($deviceName = NULL, $deviceState = NULL)
    {
        try {

            if (is_null($deviceName))
                throw new Exception("Device name is not provided or is null", 503);
            if (is_null($deviceState))
                throw new Exception("Device state name is  not provided or is null", 503);

            $putObj = array(
                'deviceState' =>$deviceState
            );

            $uri    = "/deviceStates/".$deviceName;
            $result = $this->pestObject->put($uri,$putObj);

            return $result;

        } catch (Exception $e) {
            $this->phpariObject->lasterror = $e->getMessage();
            $this->phpariObject->lasttrace = $e->getTraceAsString();
            return false;
        }
    }

    /**
     * This function is an alias to 'set' - will be deprecated in phpari 2.0
     *
     * @return mixed
     */
    public function devicestate_changestate($deviceName = NULL, $deviceState = NULL)
    {
        return $this->set($deviceName, $deviceState);
    }


    /**
     *  DELETE /deviceStates/{deviceName}
     *  Destroy a device-state controlled by ARI.
     *
     * @param null $deviceName
     * @return bool
     */
    public function remove($deviceName = NULL)
    {
        try {

            if (is_null($deviceName))
                throw new Exception("Device name is not provided or is null", 503);

            $uri    = "/deviceStates/".$deviceName;
            $result = $this->pestObject->delete($uri);

            return $result;

        } catch (Exception $e) {
            $this->phpariObject->lasterror = $e->getMessage();
            $this->phpariObject->lasttrace = $e->getTraceAsString();
            return false;
        }
    }

    /**
     * This function is an alias to 'remove' - will be deprecated in phpari 2.0
     *
     * @return mixed
     */
    public function devicestate_deletestate($deviceName = NULL)
    {
        return $this->remove($deviceName);
    }
}


