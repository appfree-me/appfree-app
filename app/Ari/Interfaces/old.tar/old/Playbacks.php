<?php
declare(strict_types=1);
namespace PhpAri3\interfaces\old;

use PhpAri3\interfaces\Exception;

/**
 * phpari - A PHP Class Library for interfacing with Asterisk(R) ARI
 * Copyright (C) 2014  Nir Simionovich
 *

 */
class Playbacks
{
    private $phpariObject;

    function __construct($connObject = NULL)
    {
        try {

            if (is_null($connObject) || is_null($connObject->ariEndpoint))
                throw new Exception("Missing PestObject or empty string", 503);

            $this->phpariObject = $connObject;
            $this->pestObject = $connObject->ariEndpoint;

        } catch (Exception $e) {
            die("Exception raised: " . $e->getMessage() . "\nFile: " . $e->getFile() . "\nLine: " . $e->getLine());
        }
    }

    /**
     * GET /playbacks/{playbackid}
     * 
     * GET details for a specific playback ID
     * 
     * @param null $playbackid
     * @return array|bool
     */
    public function show($playbackid = NULL)
    {
        try {
            $result = FALSE;

            if (is_null($this->pestObject))
                throw new Exception("PEST Object not provided or is null", 503);

            if (is_null($playbackid))
                throw new Exception("playbackid is required for this operation", 503);

            $uri = "/playbacks/" . $playbackid;
            $result = $this->pestObject->get($uri);

            return $result;
        } catch (Exception $e) {
            $this->phpariObject->lasterror = $e->getMessage();
            $this->phpariObject->lasttrace = $e->getTraceAsString();
            return FALSE;
        }
    }

    /**
     * This function is an alias to 'show' - will be deprecated in phpari 2.0
     *
     * @return mixed
     */
    public function get_playback($playbackid = NULL)
    {
        return $this->show($playbackid);
    }

    /**
     * @param null $playbackid
     * @return array|bool
     */
    public function remove($playbackid = NULL)
    {
        try {
            $result = FALSE;

            if (is_null($this->pestObject))
                throw new Exception("PEST Object not provided or is null", 503);

            if (is_null($playbackid))
                throw new Exception("playbackid is required for this operation", 503);

            $uri = "/playbacks/" . $playbackid;
            $result = $this->pestObject->delete($uri);

            return $result;
        } catch (Exception $e) {
            $this->phpariObject->lasterror = $e->getMessage();
            $this->phpariObject->lasttrace = $e->getTraceAsString();
            return FALSE;
        }
    }

    /**
     * This function is an alias to 'remove' - will be deprecated in phpari 2.0
     *
     * @return mixed
     */
    public function delete_playback($playbackid = NULL)
    {
        return $this->remove($playbackid);
    }

    /**
     * @param null $playbackid
     * @param null $control
     * @return array|bool
     */
    public function control($playbackid = NULL, $control = NULL)
    {
        try {
            $result = FALSE;

            if (is_null($this->pestObject))
                throw new Exception("PEST Object not provided or is null", 503);

            if (is_null($playbackid))
                throw new Exception("playbackid is required for this operation", 503);

            if (is_null($control))
                throw new Exception("control is required for this operation", 503);

            switch (strtolower($control)) {
                case "restart":
                case "pause":
                case "unpause":
                case "reverse":
                case "forward":
                    break;
                default:
                    throw new Exception("control property is unknown", 503);
                    break;
            }

            $uri = "/playbacks/" . $playbackid . "/control";
            $result = $this->pestObject->post($uri, array('operation' => $control));

            return $result;
        } catch (Exception $e) {
            $this->phpariObject->lasterror = $e->getMessage();
            $this->phpariObject->lasttrace = $e->getTraceAsString();
            return FALSE;
        }
    }

    /**
     * This function is an alias to 'control' - will be deprecated in phpari 2.0
     *
     * @return mixed
     */
    public function control_playback($playbackid = NULL, $control = NULL)
    {
        return $this->control($playbackid, $control);
    }
}
