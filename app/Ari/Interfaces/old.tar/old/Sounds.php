<?php

namespace PhpAri3\interfaces\old;
use PhpAri3\interfaces\Exception;

/**
 * phpari - A PHP Class Library for interfacing with Asterisk(R) ARI
 * Copyright (C) 2014  Nir Simionovich
 *

 */
class Sounds
{
    private $phpariObject;

    function __construct($connObject = NULL)
    {
        try {
            if (is_null($connObject) || is_null($connObject->ariEndpoint))
                throw new Exception("Missing PestObject or empty string", 503);

            $this->phpariObject = $connObject;
            $this->pestObject = $connObject->ariEndpoint;
        } catch (Exception $e) {
            die("Exception raised: " . $e->getMessage() . "\nFile: " . $e->getFile() . "\nLine: " . $e->getLine());
        }
    }

    /**
     * GET /sounds
     * List all sounds.
     *
     * @param string $lang - Lookup sound for a specific language.
     * @param string $format - Lookup sound in a specific format.
     * @param string $soundID - The specific sound ID you would like to get details for
     * @return bool
     */
    public function show($lang = NULL, $format = NULL, $soundID = NULL)
    {
        try {
            $uri = "/sounds";
            $uri .= (!is_null($soundID)) ? "/" . $soundID : "";

            $getOBJ = array();

            if (!is_null($lang))
                $getOBJ['lang'] = $lang;

            if (!is_null($format))
                $getOBJ['format'] = $format;

            $result = $this->pestObject->get($uri, $getOBJ);
            return $result;
        } catch (Exception $e) {
            $this->phpariObject->lasterror = $e->getMessage();
            $this->phpariObject->lasttrace = $e->getTraceAsString();
            return false;
        }
    }

    /**
     * This function is an alias to 'show' - will be deprecated in phpari 2.0
     *
     * @return mixed
     */
    public function sounds_list($lang = NULL, $format = NULL)
    {
        return $this->show($lang, $format);
    }

    /**
     *
     * GET /sounds/{soundId}
     * Get a sound's details.
     *
     * @param null $soundID
     * @return bool
     */
    public function details($soundID = NULL)
    {
        try {
            if (is_null($soundID))
                throw new Exception("Sound ID not provided or is null", 503);

            return $this->show(NULL, NULL, $soundID);
        } catch (Exception $e) {
            $this->phpariObject->lasterror = $e->getMessage();
            $this->phpariObject->lasttrace = $e->getTraceAsString();
            return false;
        }
    }

    /**
     * This function is an alias to 'details' - will be deprecated in phpari 2.0
     *
     * @return mixed
     */
    public function sound_detail($soundID = NULL)
    {
        return $this->details($soundID);
    }
}