<?php

namespace AppFree\MvgRad\States;

use app\MvgRadStasisAppController;
use AppFree\MvgRadApi;
use AppFree\AppController;
use Finite\State\State;

class MvgRadState extends State
{
    protected MvgRadApi $mvgRadApi;
    protected AppController $stateMachineSample;

    public function __construct($name, $mvgRadApi, AppController $stateMachineSample, $type = self::TYPE_NORMAL, array $transitions = array(), array $properties = array())
    {
        $this->mvgRadApi = $mvgRadApi;
        $this->stateMachineSample = $stateMachineSample;
        parent::__construct($name, $type, $transitions, $properties);
    }
}
